<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Checkmate</title>
	</head>
	<body>
		<header style="text-align:center";>
			<h1><a href="index.php"><img src="logo.png" alt="Checkmate"></h1></a>
		</header>
		<br />
		<br />
		<br />
		<br />
		<br />
		<br />
		<br />
		<br />
		<br />
		<br />
		<section style="text-align:center";>
			<a href="register.php"><button type="register" style="height: 50px; width: 200px">Register</button></a> <a href="login.php"><button type="Login" style="height: 50px; width: 200px">Login</button></a>
		</section>
		<br />
		<br />
		<br />
		<br />
		<br />
		<br />
		<br />
		<br />
		<br />
		<br />
		<footer style="float:right;">
			<a href="help.php"><img src="help.png"></a> <a href="contact.php"><img src="contact.png"></a> <a href="options.php"><img src="options.png"></a>
		</footer>
	</body>
</html>