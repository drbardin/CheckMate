<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Register | Checkmate</title>
	</head>
	<body>
		<header style="text-align:center";>
			<h1><a href="index.php"><img src="logo.png" alt="Checkmate"></h1></a>
		</header>
		<br />
		<br />
		<br />
		<br />
		<br />
		<section>
			<h2>Registration</h2>
			<br />
			<br />
			<br />
			<br />
			<br />
			<form>
			Name*: <input type="name" name="name" /><br />
			<br />
			Username*: <input type="username" name="username" /><br />
			<br />
 			Password*: <input type="password" name="password" /><br />
			<br />
			Email*: <input type="email" name="email" /><br />
			<br />
			<br />
			<input type="submit" value="Submit" />
			</form>
		</section>
		<br />
		<br />
		<br />
		<br />
		<br />
		<a href="index.php"><button type="home"><<< Home (REMOVE THIS LATER, YO)</button></a>
		<br />
		<br />
		<br />
		<br />
		<br />
		<footer style="float:right;">
			<a href="help.php"><img src="help.png"></a> <a href="contact.php"><img src="contact.png"></a> <a href="options.php"><img src="options.png"></a>
		</footer>
	</body>
</html>